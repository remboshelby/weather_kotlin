package com.example.weather.di

import dagger.Module

@Module
class WeatherModule {
}