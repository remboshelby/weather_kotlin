package com.example.myinstagram.app.di.module

class AppModule {
}