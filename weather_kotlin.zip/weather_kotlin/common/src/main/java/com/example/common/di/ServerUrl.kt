package com.example.common.di

import javax.inject.Qualifier

@Qualifier
annotation class ServerUrl {
}