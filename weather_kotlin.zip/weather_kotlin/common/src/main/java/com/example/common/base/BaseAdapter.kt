package com.example.common.base

class BaseAdapter {
}