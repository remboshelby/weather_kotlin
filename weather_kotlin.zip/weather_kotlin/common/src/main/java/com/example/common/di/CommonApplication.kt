package com.example.common.di

interface CommonApplication {
    abstract fun component(): CommonComponent
}