package com.example.common.di.modules

import dagger.Module

@Module class SharedPreferenceModule {
}