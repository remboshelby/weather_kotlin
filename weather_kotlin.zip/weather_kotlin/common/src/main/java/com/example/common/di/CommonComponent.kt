package com.example.common.di

interface CommonComponent {
}