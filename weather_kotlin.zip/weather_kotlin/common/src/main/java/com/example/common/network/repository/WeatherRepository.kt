package com.example.common.network.repository

class WeatherRepository {
}