package com.example.common.network.api

import retrofit2.http.GET

interface WeatherApi {

}